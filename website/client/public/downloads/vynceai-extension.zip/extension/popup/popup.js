/**
 * VynceAI Extension - Popup Script
 * Handles user interactions and communication with background service worker
 * Now includes memory management for context-aware conversations
 */

import { formatResponse, sanitizeInput, getCurrentTimestamp } from '../utils/helpers.js';

// DOM Elements
const chatContainer = document.getElementById('chat-container');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const voiceBtn = document.getElementById('voice-btn');
const voiceIndicator = document.getElementById('voice-indicator');
const clearBtn = document.getElementById('clear-btn');
const memoryBtn = document.getElementById('memory-btn');
const clearMemoryBtn = document.getElementById('clear-memory-btn');
const settingsBtn = document.getElementById('settings-btn');
const modelSelect = document.getElementById('model-select');
const statusText = document.querySelector('.status-text');
const statusDot = document.querySelector('.status-dot');

// Mode Elements
const chatModeBtn = document.getElementById('chat-mode-btn');
const commandModeBtn = document.getElementById('command-mode-btn');

// Memory Elements
const memorySection = document.getElementById('memory-section');
const memoryList = document.getElementById('memory-list');
const memoryStats = document.getElementById('memory-stats');
const closeMemoryBtn = document.getElementById('close-memory-btn');

// State
let conversationHistory = [];
let isProcessing = false;
let currentMode = 'chat'; // 'chat' or 'command'
let recognition = null;
let isListening = false;

// Memory Constants
const MEMORY_KEY = 'vynceai_memory';
const MAX_MEMORY_ITEMS = 20;

/**
 * Initialize the popup
 */
function init() {
  loadConversationHistory();
  loadSelectedModel();
  setupEventListeners();
  initVoiceRecognition();
  updateStatus('ready');
  updateMemoryBadge();
  
  // Auto-focus input
  userInput.focus();
}

/**
 * Setup all event listeners
 */
function setupEventListeners() {
  // Send message on button click
  sendBtn.addEventListener('click', handleSendMessage);
  
  // Voice input
  voiceBtn.addEventListener('click', toggleVoiceRecognition);
  
  // Mode switching
  chatModeBtn.addEventListener('click', () => switchMode('chat'));
  commandModeBtn.addEventListener('click', () => switchMode('command'));
  
  // Send message on Enter (Shift+Enter for new line)
  userInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  });
  
  // Auto-resize textarea
  userInput.addEventListener('input', autoResizeTextarea);
  
  // Clear conversation
  clearBtn.addEventListener('click', handleClearConversation);
  
  // Memory handlers
  memoryBtn.addEventListener('click', handleShowMemory);
  clearMemoryBtn.addEventListener('click', handleClearMemory);
  closeMemoryBtn.addEventListener('click', handleCloseMemory);
  
  // Settings (placeholder for now)
  settingsBtn.addEventListener('click', handleSettings);
  
  // Save selected model
  modelSelect.addEventListener('change', () => {
    chrome.storage.local.set({ selectedModel: modelSelect.value });
  });
}

// ============================================
// VOICE RECOGNITION
// ============================================

/**
 * Initialize Web Speech API
 */
function initVoiceRecognition() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    console.warn('Speech recognition not supported');
    voiceBtn.disabled = true;
    voiceBtn.title = 'Speech recognition not supported in this browser';
    return;
  }
  
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';
  
  recognition.onstart = () => {
    isListening = true;
    voiceBtn.classList.add('listening');
    voiceIndicator.style.display = 'flex';
    updateStatus('listening');
  };
  
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    userInput.value = transcript;
    autoResizeTextarea();
    
    // Auto-send in command mode
    if (currentMode === 'command') {
      setTimeout(() => handleSendMessage(), 300);
    }
  };
  
  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    stopVoiceRecognition();
    
    if (event.error !== 'no-speech' && event.error !== 'aborted') {
      showError('Voice recognition error: ' + event.error);
    }
  };
  
  recognition.onend = () => {
    stopVoiceRecognition();
  };
}

/**
 * Toggle voice recognition on/off
 */
function toggleVoiceRecognition() {
  if (!recognition) {
    showError('Voice recognition not available');
    return;
  }
  
  if (isListening) {
    recognition.stop();
  } else {
    try {
      recognition.start();
    } catch (error) {
      console.error('Error starting recognition:', error);
      showError('Failed to start voice recognition');
    }
  }
}

/**
 * Stop voice recognition
 */
function stopVoiceRecognition() {
  isListening = false;
  voiceBtn.classList.remove('listening');
  voiceIndicator.style.display = 'none';
  updateStatus('ready');
}

// ============================================
// MODE SWITCHING (Chat vs Command)
// ============================================

/**
 * Switch between Chat and Command modes
 */
function switchMode(mode) {
  currentMode = mode;
  
  if (mode === 'chat') {
    chatModeBtn.classList.add('active');
    commandModeBtn.classList.remove('active');
    userInput.placeholder = 'Ask VynceAI anything...';
    showInfo('Chat Mode: Talk to AI with context and memory');
  } else {
    commandModeBtn.classList.add('active');
    chatModeBtn.classList.remove('active');
    userInput.placeholder = 'Speak a command: scroll, open tab, go to...';
    showInfo('Command Mode: Voice commands for browser automation');
  }
}

/**
 * Show info message
 */
function showInfo(message) {
  const infoDiv = document.createElement('div');
  infoDiv.className = 'error-message';
  infoDiv.style.background = 'rgba(59, 130, 246, 0.2)';
  infoDiv.style.borderColor = 'rgba(59, 130, 246, 0.4)';
  infoDiv.style.color = '#3b82f6';
  infoDiv.innerHTML = `
    <svg class="action-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
    </svg>
    <span>${message}</span>
  `;
  
  chatContainer.insertBefore(infoDiv, chatContainer.firstChild);
  setTimeout(() => infoDiv.remove(), 3000);
}

/**
 * Handle sending a message
 */
async function handleSendMessage() {
  const message = sanitizeInput(userInput.value.trim());
  
  if (!message || isProcessing) return;
  
  // Check if in command mode
  if (currentMode === 'command') {
    await handleCommand(message);
    return;
  }
  
  const selectedModel = modelSelect.value;
  
  // Clear input and reset height
  userInput.value = '';
  userInput.style.height = 'auto';
  
  // Add user message to UI
  addMessage('user', message);
  
  // Show loading state
  setProcessingState(true);
  const loadingId = addLoadingMessage();
  
  try {
    // Get page context and recent memory
    const context = await getPageContext();
    const recentMemory = await getRecentMemory(3);
    
    console.log('Sending with memory:', recentMemory.length, 'items');
    
    // Send message to background script with memory
    const response = await chrome.runtime.sendMessage({
      type: 'SEND_PROMPT',
      payload: {
        model: selectedModel,
        prompt: message,
        context: context,
        memory: recentMemory
      }
    });
    
    // Remove loading message
    removeLoadingMessage(loadingId);
    
    if (response.success) {
      // Add AI response to UI
      const aiResponse = response.data?.response || response.text || response.response;
      addMessage('ai', aiResponse, response.data?.model || selectedModel);
      
      // Save to memory
      await saveToMemory(message, aiResponse, context, selectedModel);
      updateMemoryBadge();
      
      // Save to history
      saveConversation();
    } else {
      // Show error
      showError(response.error || 'Failed to get response');
    }
    
  } catch (error) {
    console.error('Error sending message:', error);
    removeLoadingMessage(loadingId);
    showError('Failed to communicate with AI. Please try again.');
  } finally {
    setProcessingState(false);
  }
}

// ============================================
// COMMAND MODE HANDLERS
// ============================================

/**
 * Handle browser automation commands
 */
async function handleCommand(command) {
  const lowerCommand = command.toLowerCase();
  
  // Clear input
  userInput.value = '';
  userInput.style.height = 'auto';
  
  // Add command to chat
  addMessage('user', command);
  
  try {
    // Send command to background script
    const response = await chrome.runtime.sendMessage({
      type: 'EXECUTE_COMMAND',
      payload: { command: lowerCommand }
    });
    
    if (response.success) {
      addMessage('ai', `✅ ${response.message}`, 'Command');
    } else {
      showError(response.error || 'Command failed');
    }
  } catch (error) {
    console.error('Error executing command:', error);
    showError('Failed to execute command');
  }
}

/**
 * Add a message to the chat container
 */
function addMessage(sender, content, model = null) {
  // Remove welcome message if exists
  const welcomeMsg = chatContainer.querySelector('.welcome-message');
  if (welcomeMsg) {
    welcomeMsg.remove();
  }
  
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${sender}-message`;
  
  const timestamp = getCurrentTimestamp();
  const avatar = sender === 'user' ? 'You' : '🤖';
  const senderName = sender === 'user' ? 'You' : (model ? `VynceAI (${model})` : 'VynceAI');
  
  messageDiv.innerHTML = `
    <div class="message-header">
      <div class="message-avatar">${sender === 'user' ? 'Y' : 'V'}</div>
      <span class="message-sender">${senderName}</span>
      <span class="message-time">${timestamp}</span>
    </div>
    <div class="message-content">${formatResponse(content)}</div>
  `;
  
  chatContainer.appendChild(messageDiv);
  
  // Scroll to bottom
  chatContainer.scrollTop = chatContainer.scrollHeight;
  
  // Add to conversation history
  conversationHistory.push({
    sender,
    content,
    model,
    timestamp: Date.now()
  });
}

/**
 * Add loading message while waiting for AI response
 */
function addLoadingMessage() {
  const loadingId = `loading-${Date.now()}`;
  const loadingDiv = document.createElement('div');
  loadingDiv.className = 'message ai-message';
  loadingDiv.id = loadingId;
  
  loadingDiv.innerHTML = `
    <div class="message-header">
      <div class="message-avatar">V</div>
      <span class="message-sender">VynceAI</span>
    </div>
    <div class="loading-message">
      <span>Thinking</span>
      <div class="loading-dots">
        <div class="loading-dot"></div>
        <div class="loading-dot"></div>
        <div class="loading-dot"></div>
      </div>
    </div>
  `;
  
  chatContainer.appendChild(loadingDiv);
  chatContainer.scrollTop = chatContainer.scrollHeight;
  
  return loadingId;
}

/**
 * Remove loading message
 */
function removeLoadingMessage(loadingId) {
  const loadingElement = document.getElementById(loadingId);
  if (loadingElement) {
    loadingElement.remove();
  }
}

/**
 * Show error message
 */
function showError(message) {
  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-message';
  errorDiv.innerHTML = `
    <svg class="action-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
    </svg>
    <span>${message}</span>
  `;
  
  chatContainer.appendChild(errorDiv);
  chatContainer.scrollTop = chatContainer.scrollHeight;
  
  // Remove after 5 seconds
  setTimeout(() => errorDiv.remove(), 5000);
}

/**
 * Handle clear conversation
 */
function handleClearConversation() {
  if (confirm('Clear all conversation history?')) {
    conversationHistory = [];
    chatContainer.innerHTML = `
      <div class="welcome-message">
        <svg class="welcome-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path>
        </svg>
        <h3>Welcome to VynceAI</h3>
        <p>Ask me anything or let me help you automate tasks on this webpage.</p>
      </div>
    `;
    saveConversation();
  }
}

/**
 * Handle settings button click
 */
function handleSettings() {
  // TODO: Implement settings panel
  alert('Settings panel coming soon!');
}

/**
 * Auto-resize textarea based on content
 */
function autoResizeTextarea() {
  userInput.style.height = 'auto';
  userInput.style.height = Math.min(userInput.scrollHeight, 120) + 'px';
}

/**
 * Set processing state
 */
function setProcessingState(processing) {
  isProcessing = processing;
  sendBtn.disabled = processing;
  userInput.disabled = processing;
  updateStatus(processing ? 'processing' : 'ready');
}

/**
 * Update status indicator
 */
function updateStatus(status) {
  const statusMap = {
    ready: { text: 'Ready', color: '#22c55e' },
    processing: { text: 'Processing...', color: '#f59e0b' },
    listening: { text: 'Listening...', color: '#ef4444' },
    error: { text: 'Error', color: '#ef4444' }
  };
  
  const { text, color } = statusMap[status] || statusMap.ready;
  statusText.textContent = text;
  statusDot.style.background = color;
  
  // Add listening class to status indicator
  const statusIndicator = document.querySelector('.status-indicator');
  if (status === 'listening') {
    statusIndicator.classList.add('listening');
  } else {
    statusIndicator.classList.remove('listening');
  }
}

/**
 * Get current page context for AI
 */
async function getPageContext() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab?.id) return null;
    
    // Get page info from content script
    const response = await chrome.tabs.sendMessage(tab.id, {
      type: 'GET_PAGE_CONTEXT'
    });
    
    return response;
  } catch (error) {
    console.error('Error getting page context:', error);
    return null;
  }
}

/**
 * Load conversation history from storage
 */
async function loadConversationHistory() {
  try {
    const result = await chrome.storage.local.get(['conversationHistory']);
    
    if (result.conversationHistory && result.conversationHistory.length > 0) {
      conversationHistory = result.conversationHistory;
      
      // Remove welcome message
      const welcomeMsg = chatContainer.querySelector('.welcome-message');
      if (welcomeMsg) {
        welcomeMsg.remove();
      }
      
      // Render conversation history
      conversationHistory.forEach(msg => {
        addMessage(msg.sender, msg.content, msg.model);
      });
    }
  } catch (error) {
    console.error('Error loading conversation history:', error);
  }
}

/**
 * Save conversation to storage
 */
function saveConversation() {
  chrome.storage.local.set({ conversationHistory });
}

/**
 * Load selected model from storage
 */
async function loadSelectedModel() {
  try {
    const result = await chrome.storage.local.get(['selectedModel']);
    if (result.selectedModel) {
      modelSelect.value = result.selectedModel;
    }
  } catch (error) {
    console.error('Error loading selected model:', error);
  }
}

// ============================================
// MEMORY MANAGEMENT FUNCTIONS
// ============================================

async function getMemory() {
  try {
    const result = await chrome.storage.local.get([MEMORY_KEY]);
    return result[MEMORY_KEY] || [];
  } catch (error) {
    console.error('Error getting memory:', error);
    return [];
  }
}

async function getRecentMemory(count = 3) {
  try {
    const memory = await getMemory();
    return memory.slice(0, count).map(item => ({
      user: item.user,
      bot: item.bot,
      timestamp: item.timestamp
    }));
  } catch (error) {
    console.error('Error getting recent memory:', error);
    return [];
  }
}

async function saveToMemory(userMessage, botResponse, context, model) {
  try {
    const memory = await getMemory();
    
    const interaction = {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      user: userMessage,
      bot: botResponse,
      model: model,
      context: context ? {
        url: context.url,
        title: context.title
      } : null
    };
    
    memory.unshift(interaction);
    const trimmedMemory = memory.slice(0, MAX_MEMORY_ITEMS);
    
    await chrome.storage.local.set({ [MEMORY_KEY]: trimmedMemory });
    console.log('Memory saved:', interaction.id);
  } catch (error) {
    console.error('Error saving memory:', error);
  }
}

async function clearAllMemory() {
  try {
    await chrome.storage.local.remove(MEMORY_KEY);
    console.log('Memory cleared');
    return true;
  } catch (error) {
    console.error('Error clearing memory:', error);
    return false;
  }
}

async function getMemoryStats() {
  try {
    const memory = await getMemory();
    return {
      count: memory.length,
      oldestTimestamp: memory.length > 0 ? memory[memory.length - 1].timestamp : null,
      newestTimestamp: memory.length > 0 ? memory[0].timestamp : null,
      totalSize: JSON.stringify(memory).length
    };
  } catch (error) {
    console.error('Error getting memory stats:', error);
    return { count: 0 };
  }
}

async function handleShowMemory() {
  try {
    const memory = await getMemory();
    
    memoryList.innerHTML = '';
    
    if (memory.length === 0) {
      memoryList.innerHTML = `
        <div class="memory-empty">
          <div class="memory-empty-icon">💭</div>
          <div class="memory-empty-text">No memory yet<br>Start chatting to build memory</div>
        </div>
      `;
    } else {
      memory.forEach(item => {
        const memoryItem = document.createElement('div');
        memoryItem.className = 'memory-item';
        
        const timestamp = new Date(item.timestamp).toLocaleString('en-US', {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
        
        const contextInfo = item.context ? 
          `<div class="memory-context">${escapeHtml(item.context.title || item.context.url)}</div>` : '';
        
        memoryItem.innerHTML = `
          <div class="memory-item-header">
            <span class="memory-timestamp">${timestamp}</span>
            <span class="memory-model">${item.model || 'unknown'}</span>
          </div>
          <div class="memory-user">${escapeHtml(item.user)}</div>
          <div class="memory-bot">${escapeHtml(item.bot.substring(0, 150))}${item.bot.length > 150 ? '...' : ''}</div>
          ${contextInfo}
        `;
        
        memoryList.appendChild(memoryItem);
      });
    }
    
    const stats = await getMemoryStats();
    memoryStats.innerHTML = `
      <span>💾 ${stats.count} interactions</span>
      <span>📦 ${(stats.totalSize / 1024).toFixed(1)} KB</span>
    `;
    
    memorySection.style.display = 'flex';
  } catch (error) {
    console.error('Error showing memory:', error);
    showError('Failed to load memory');
  }
}

function handleCloseMemory() {
  memorySection.style.display = 'none';
}

async function handleClearMemory() {
  const confirmed = confirm('Clear all memory? This cannot be undone.');
  
  if (confirmed) {
    const success = await clearAllMemory();
    
    if (success) {
      showSuccess('Memory cleared successfully');
      updateMemoryBadge();
      
      if (memorySection.style.display === 'flex') {
        handleShowMemory();
      }
    } else {
      showError('Failed to clear memory');
    }
  }
}

async function updateMemoryBadge() {
  try {
    const stats = await getMemoryStats();
    if (stats.count > 0) {
      memoryBtn.setAttribute('data-count', stats.count);
      memoryBtn.style.position = 'relative';
    } else {
      memoryBtn.removeAttribute('data-count');
    }
  } catch (error) {
    console.error('Error updating memory badge:', error);
  }
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function showSuccess(message) {
  const successDiv = document.createElement('div');
  successDiv.className = 'error-message';
  successDiv.style.background = 'rgba(76, 175, 80, 0.2)';
  successDiv.style.borderColor = 'rgba(76, 175, 80, 0.4)';
  successDiv.style.color = '#4caf50';
  successDiv.innerHTML = `
    <svg class="action-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
    </svg>
    <span>${message}</span>
  `;
  
  chatContainer.insertBefore(successDiv, chatContainer.firstChild);
  setTimeout(() => successDiv.remove(), 3000);
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
